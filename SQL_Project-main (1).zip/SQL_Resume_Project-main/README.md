# SQL_Resume_Project
SQL Portfolio Project for 
Data analyst to showcase in Resume
<br>
click on Link : https://youtu.be/sxgAb6FGTBE
<br>
👉 Watch Video : <br>
[![Watch the video](https://img.youtube.com/vi/sxgAb6FGTBE/hqdefault.jpg)](https://www.youtube.com/watch?v=sxgAb6FGTBE&t=1s)


